# Projeto-Google Cloud-DevOps Fazendo Deploy de um app de clima no Cloud Run
